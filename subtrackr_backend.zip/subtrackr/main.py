from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os
import logging

from database import create_tables
from routers.auth_router import router as auth_router
from routers.subscriptions_router import router as sub_router
from email_service import start_scheduler

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("main")

app = FastAPI(
    title="SubTrackr API",
    description="Backend for SubTrackr — subscription tracking with reminders",
    version="1.0.0",
)

# ── CORS — allow the frontend to talk to the API ───────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # tighten in production: ["https://yourdomain.com"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Create DB tables on startup ────────────────────────────────────────────
@app.on_event("startup")
def startup():
    create_tables()
    start_scheduler()
    logger.info("SubTrackr API started ✅")

# ── Routers ────────────────────────────────────────────────────────────────
app.include_router(auth_router)
app.include_router(sub_router)

# ── Serve the frontend (index.html) at root ────────────────────────────────
FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "static")
if os.path.isdir(FRONTEND_DIR):
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

    @app.get("/", include_in_schema=False)
    def serve_frontend():
        return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

# ── Health check ───────────────────────────────────────────────────────────
@app.get("/health", tags=["System"])
def health():
    return {"status": "ok", "service": "SubTrackr API"}
