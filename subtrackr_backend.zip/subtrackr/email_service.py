"""
Email reminder service.
Runs a background job every day at 8 AM that checks for upcoming renewals
and sends reminder emails to users who have notifications enabled.

By default uses Python's smtplib (Gmail SMTP). Configure via environment
variables or edit the SMTP settings below.
"""
import os
import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import date, datetime
from apscheduler.schedulers.background import BackgroundScheduler
from sqlalchemy.orm import Session
from database import SessionLocal, Subscription, User

logger = logging.getLogger("reminders")

# ── SMTP Config ── set these as env vars or edit directly ──────────────────
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")          # your Gmail address
SMTP_PASS = os.getenv("SMTP_PASS", "")          # Gmail App Password
FROM_NAME = "SubTrackr"


def send_reminder_email(to_email: str, user_name: str, subscriptions: list):
    """Send a renewal reminder email."""
    if not SMTP_USER or not SMTP_PASS:
        logger.warning("SMTP not configured — skipping email to %s", to_email)
        return False

    subject = f"⏰ SubTrackr: {len(subscriptions)} subscription(s) renewing soon"

    rows = ""
    for s in subscriptions:
        days = s["days_until"]
        urgency = "🔴" if days <= 1 else "🟡" if days <= 3 else "🟢"
        rows += f"""
        <tr>
          <td style="padding:10px 14px;border-bottom:1px solid #1e2540">{s['icon']} {s['name']}</td>
          <td style="padding:10px 14px;border-bottom:1px solid #1e2540">${s['price']:.2f}/{s['billing_cycle']}</td>
          <td style="padding:10px 14px;border-bottom:1px solid #1e2540">{s['renewal_date']}</td>
          <td style="padding:10px 14px;border-bottom:1px solid #1e2540">{urgency} {days} day{'s' if days != 1 else ''}</td>
        </tr>"""

    html = f"""
    <html><body style="background:#0a0e1a;color:#e8eaf0;font-family:DM Sans,sans-serif;margin:0;padding:0">
    <div style="max-width:600px;margin:40px auto;background:#131827;border-radius:16px;overflow:hidden;border:1px solid rgba(255,255,255,0.07)">
      <div style="background:linear-gradient(135deg,#4f8ef7,#7c6ff7);padding:32px 40px">
        <div style="font-size:24px;font-weight:800;color:#fff">📊 SubTrackr</div>
        <div style="font-size:15px;color:rgba(255,255,255,0.8);margin-top:6px">Subscription Renewal Reminder</div>
      </div>
      <div style="padding:32px 40px">
        <p style="font-size:16px;margin-bottom:24px">Hi {user_name or 'there'} 👋,</p>
        <p style="color:#8b90a0;margin-bottom:24px">
          The following subscriptions are renewing soon. Review them and cancel any you no longer need.
        </p>
        <table style="width:100%;border-collapse:collapse;font-size:14px">
          <thead>
            <tr style="background:#1a2035;color:#8b90a0;font-size:12px;text-transform:uppercase">
              <th style="padding:10px 14px;text-align:left">Service</th>
              <th style="padding:10px 14px;text-align:left">Price</th>
              <th style="padding:10px 14px;text-align:left">Renews On</th>
              <th style="padding:10px 14px;text-align:left">Time Left</th>
            </tr>
          </thead>
          <tbody>{rows}</tbody>
        </table>
      </div>
      <div style="padding:20px 40px;border-top:1px solid rgba(255,255,255,0.07);color:#5a6070;font-size:12px">
        You're receiving this because you enabled reminders in SubTrackr.
        Log in to manage your subscriptions or turn off notifications in Settings.
      </div>
    </div>
    </body></html>"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = f"{FROM_NAME} <{SMTP_USER}>"
    msg["To"] = to_email
    msg.attach(MIMEText(html, "html"))

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT) as server:
            server.ehlo()
            server.starttls()
            server.login(SMTP_USER, SMTP_PASS)
            server.sendmail(SMTP_USER, to_email, msg.as_string())
        logger.info("Reminder sent to %s", to_email)
        return True
    except Exception as e:
        logger.error("Failed to send email to %s: %s", to_email, e)
        return False


def check_and_send_reminders():
    """Daily job: find due reminders and email users."""
    logger.info("Running daily reminder check — %s", datetime.now().strftime("%Y-%m-%d %H:%M"))
    db: Session = SessionLocal()
    try:
        users = db.query(User).filter(User.is_active == True, User.email_notifications == True).all()
        today = date.today()

        for user in users:
            subs = db.query(Subscription).filter(
                Subscription.user_id == user.id,
                Subscription.status == "Active"
            ).all()

            due = []
            for s in subs:
                try:
                    renewal = datetime.strptime(s.renewal_date, "%Y-%m-%d").date()
                    days_left = (renewal - today).days
                    if 0 <= days_left <= s.reminder_days:
                        due.append({
                            "icon": s.icon,
                            "name": s.name,
                            "price": s.price,
                            "billing_cycle": s.billing_cycle,
                            "renewal_date": s.renewal_date,
                            "days_until": days_left,
                        })
                except ValueError:
                    continue

            if due:
                send_reminder_email(user.email, user.full_name or "", due)
    finally:
        db.close()


def start_scheduler():
    scheduler = BackgroundScheduler()
    # Run every day at 08:00 AM server time
    scheduler.add_job(check_and_send_reminders, "cron", hour=8, minute=0)
    scheduler.start()
    logger.info("Reminder scheduler started — fires daily at 08:00")
    return scheduler
