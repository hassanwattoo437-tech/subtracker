from pydantic import BaseModel, EmailStr, field_validator
from typing import Optional
from datetime import datetime


# ── Auth ──────────────────────────────────────────────────────────────────────

class UserRegister(BaseModel):
    email: EmailStr
    password: str
    full_name: Optional[str] = None

    @field_validator("password")
    @classmethod
    def password_length(cls, v):
        if len(v) < 6:
            raise ValueError("Password must be at least 6 characters")
        return v


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserUpdate(BaseModel):
    full_name: Optional[str] = None
    email_notifications: Optional[bool] = None
    default_reminder_days: Optional[int] = None


class UserOut(BaseModel):
    id: int
    email: str
    full_name: Optional[str]
    is_active: bool
    email_notifications: bool
    default_reminder_days: int
    created_at: datetime

    model_config = {"from_attributes": True}


class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserOut


# ── Subscriptions ─────────────────────────────────────────────────────────────

class SubscriptionCreate(BaseModel):
    name: str
    price: float
    billing_cycle: Optional[str] = "monthly"
    category: Optional[str] = "Other"
    status: Optional[str] = "Active"
    renewal_date: str          # YYYY-MM-DD
    reminder_days: Optional[int] = 3
    icon: Optional[str] = "📦"
    color: Optional[str] = "rgba(79,142,247,0.1)"
    notes: Optional[str] = None

    @field_validator("price")
    @classmethod
    def price_positive(cls, v):
        if v <= 0:
            raise ValueError("Price must be positive")
        return v


class SubscriptionUpdate(BaseModel):
    name: Optional[str] = None
    price: Optional[float] = None
    billing_cycle: Optional[str] = None
    category: Optional[str] = None
    status: Optional[str] = None
    renewal_date: Optional[str] = None
    reminder_days: Optional[int] = None
    icon: Optional[str] = None
    color: Optional[str] = None
    notes: Optional[str] = None


class SubscriptionOut(BaseModel):
    id: int
    name: str
    price: float
    billing_cycle: str
    category: str
    status: str
    renewal_date: str
    reminder_days: int
    icon: str
    color: str
    notes: Optional[str]
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


# ── Analytics ─────────────────────────────────────────────────────────────────

class AnalyticsSummary(BaseModel):
    total_monthly: float
    total_annual: float
    active_count: int
    paused_count: int
    by_category: dict
    most_expensive: Optional[str]
    upcoming_renewals: list
