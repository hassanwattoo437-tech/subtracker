from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, date, timedelta
from database import get_db, Subscription, User
from schemas import SubscriptionCreate, SubscriptionUpdate, SubscriptionOut, AnalyticsSummary
from auth import get_current_user

router = APIRouter(prefix="/subscriptions", tags=["Subscriptions"])

CATEGORY_ICONS = {
    "Entertainment": "🎬",
    "Productivity": "💼",
    "Cloud / Storage": "☁️",
    "Health & Fitness": "💪",
    "Finance": "💳",
    "News & Media": "📰",
    "Gaming": "🎮",
    "Other": "📦",
}


def _monthly_price(sub: Subscription) -> float:
    return sub.price if sub.billing_cycle == "monthly" else sub.price / 12


def _days_until(date_str: str) -> int:
    try:
        d = datetime.strptime(date_str, "%Y-%m-%d").date()
        return (d - date.today()).days
    except Exception:
        return 999


# ── CRUD ──────────────────────────────────────────────────────────────────────

@router.get("/", response_model=List[SubscriptionOut])
def list_subscriptions(
    status: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = db.query(Subscription).filter(Subscription.user_id == current_user.id)
    if status:
        q = q.filter(Subscription.status == status)
    if category:
        q = q.filter(Subscription.category == category)
    return q.order_by(Subscription.renewal_date).all()


@router.post("/", response_model=SubscriptionOut, status_code=201)
def create_subscription(
    body: SubscriptionCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    icon = body.icon if body.icon != "📦" else CATEGORY_ICONS.get(body.category, "📦")
    sub = Subscription(
        user_id=current_user.id,
        **body.model_dump(exclude={"icon"}),
        icon=icon,
    )
    db.add(sub)
    db.commit()
    db.refresh(sub)
    return sub


@router.get("/{sub_id}", response_model=SubscriptionOut)
def get_subscription(sub_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    sub = db.query(Subscription).filter(Subscription.id == sub_id, Subscription.user_id == current_user.id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    return sub


@router.patch("/{sub_id}", response_model=SubscriptionOut)
def update_subscription(
    sub_id: int,
    body: SubscriptionUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    sub = db.query(Subscription).filter(Subscription.id == sub_id, Subscription.user_id == current_user.id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    for field, value in body.model_dump(exclude_none=True).items():
        setattr(sub, field, value)
    db.commit()
    db.refresh(sub)
    return sub


@router.delete("/{sub_id}", status_code=204)
def delete_subscription(sub_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    sub = db.query(Subscription).filter(Subscription.id == sub_id, Subscription.user_id == current_user.id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    db.delete(sub)
    db.commit()


# ── Analytics ─────────────────────────────────────────────────────────────────

@router.get("/analytics/summary", response_model=AnalyticsSummary)
def analytics_summary(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    subs = db.query(Subscription).filter(Subscription.user_id == current_user.id).all()
    active = [s for s in subs if s.status == "Active"]

    total_monthly = sum(_monthly_price(s) for s in active)

    by_category: dict = {}
    for s in active:
        by_category[s.category] = round(by_category.get(s.category, 0) + _monthly_price(s), 2)

    most_expensive = max(active, key=lambda s: s.price).name if active else None

    upcoming = sorted(
        [s for s in active if 0 <= _days_until(s.renewal_date) <= 30],
        key=lambda s: _days_until(s.renewal_date),
    )
    upcoming_list = [
        {"id": s.id, "name": s.name, "icon": s.icon, "price": s.price,
         "renewal_date": s.renewal_date, "days_until": _days_until(s.renewal_date)}
        for s in upcoming
    ]

    return AnalyticsSummary(
        total_monthly=round(total_monthly, 2),
        total_annual=round(total_monthly * 12, 2),
        active_count=len(active),
        paused_count=len([s for s in subs if s.status == "Paused"]),
        by_category=by_category,
        most_expensive=most_expensive,
        upcoming_renewals=upcoming_list,
    )
