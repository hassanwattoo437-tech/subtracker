# SubTrackr Backend

A FastAPI + SQLite backend for the SubTrackr subscription management app.

## Features
- ✅ User registration & login (JWT auth, 30-day tokens)
- ✅ Full CRUD for subscriptions (create, read, update, delete)
- ✅ Analytics API (monthly totals, by category, upcoming renewals)
- ✅ Daily email reminders (via Gmail SMTP / any SMTP)
- ✅ Serves the frontend at `/`
- ✅ Auto-generated API docs at `/docs`

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. (Optional) Configure email reminders
Set these environment variables to enable real email alerts:
```bash
export SMTP_USER="your@gmail.com"
export SMTP_PASS="your-gmail-app-password"   # Use a Gmail App Password
```
> To get a Gmail App Password: Google Account → Security → 2-Step Verification → App Passwords

### 3. Run the server
```bash
uvicorn main:app --reload --port 8000
```

### 4. Open the app
- **App:** http://localhost:8000
- **API Docs (Swagger):** http://localhost:8000/docs
- **Health check:** http://localhost:8000/health

## API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/auth/register` | Create account |
| POST | `/auth/login` | Login, get JWT token |
| GET | `/auth/me` | Get current user |
| PATCH | `/auth/me` | Update profile / notification settings |
| DELETE | `/auth/me` | Delete account |

### Subscriptions
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/subscriptions/` | List all subscriptions |
| POST | `/subscriptions/` | Add a subscription |
| PATCH | `/subscriptions/{id}` | Update a subscription |
| DELETE | `/subscriptions/{id}` | Delete a subscription |
| GET | `/subscriptions/analytics/summary` | Spending analytics |

### Filters
```
GET /subscriptions/?status=Active
GET /subscriptions/?category=Entertainment
```

## Project Structure
```
subtrackr/
├── main.py               # App entry point + CORS + scheduler startup
├── database.py           # SQLAlchemy models (User, Subscription)
├── schemas.py            # Pydantic request/response schemas
├── auth.py               # JWT helpers, password hashing
├── email_service.py      # SMTP email + APScheduler daily job
├── requirements.txt
├── routers/
│   ├── auth_router.py        # /auth/* endpoints
│   └── subscriptions_router.py  # /subscriptions/* endpoints
└── static/
    └── index.html        # Frontend (served at /)
```

## Data stored in SQLite
The database file `subtrackr.db` is created automatically in the project folder on first run. No setup needed.

## Deploying to production
1. Change `SECRET_KEY` in `auth.py` to a long random string
2. Restrict CORS in `main.py` to your domain
3. Use `uvicorn main:app --host 0.0.0.0 --port 8000` (or behind nginx)
4. Consider PostgreSQL instead of SQLite for multi-user scale
